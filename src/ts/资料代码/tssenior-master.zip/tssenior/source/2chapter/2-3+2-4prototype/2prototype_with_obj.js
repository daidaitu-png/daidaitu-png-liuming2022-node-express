
let obj = { username: "wangwu", age: 23 }
let objnew = obj;

obj = { address: "北京海淀区西三环", age: 39 }
console.log("obj:", obj);
console.log("obj2:", objnew)


//obj.username = "lisi"
//obj.phone = "123"
// let objnew = new Object();
// objnew.username = "王五"
// objnew.age = 33
// console.log("objnew:", objnew);
//let obj={}