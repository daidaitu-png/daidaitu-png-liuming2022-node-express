enum OO {
  KK = 1,
  PP,
  MM
}
console.log(typeof OO);

let dd: OO = OO.KK;

export { }
